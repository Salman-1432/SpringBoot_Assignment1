The Chinook Database used in this application is a MIT-licensed sample database which can be found at:

http://chinookdatabase.codeplex.com/

License: http://chinookdatabase.codeplex.com/license
