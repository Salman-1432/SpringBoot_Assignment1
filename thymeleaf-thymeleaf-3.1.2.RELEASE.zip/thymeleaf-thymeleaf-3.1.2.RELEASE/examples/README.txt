Thymeleaf Example Applications
==============================

This set of example applications can be built using Maven both individually
and also all together from this folder with:

$ mvn clean compile package

Check each application's folder for instructions on how to run them.
