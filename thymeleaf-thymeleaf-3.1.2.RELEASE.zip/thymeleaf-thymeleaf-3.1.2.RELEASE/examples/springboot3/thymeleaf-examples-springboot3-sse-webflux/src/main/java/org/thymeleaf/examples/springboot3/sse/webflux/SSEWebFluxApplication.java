package org.thymeleaf.examples.springboot3.sse.webflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SSEWebFluxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SSEWebFluxApplication.class, args);
	}
}
