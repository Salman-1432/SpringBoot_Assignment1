package org.thymeleaf.examples.springboot3.stsm.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StsmMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(StsmMvcApplication.class, args);
	}
}
